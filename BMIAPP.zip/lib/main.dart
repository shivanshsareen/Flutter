import 'package:flutter/material.dart';

import 'screens/firstpage.dart';

void main() => runApp(
      const MaterialApp(
        debugShowCheckedModeBanner: false, //to remove
        home: FirstPage(),
        // routes: {
        //   "/home": (context) => FirstPage(),
        // },
      ),
    );
